<div class="p-5">
    <p class="text-center">QUẢN LÝ SẢN PHẨM</p>
    <a href="?page=product&act=add" class="btn btn-primary">Thêm sản phẩm</a>    
    <table class="table table-hover">
        <thead>
            <tr>
                <th>Mã sản phẩm</th>
                <th>Tên sản phẩm</th>
                <th>Giá</th>
                <th>Giá khuyến mãi</th>
                <th>Hình ảnh</th>
                <th>Danh mục</th>
                <th>Số lượng</th>
                <th>Trạng thái</th>
                
                <th>Ngày nhập</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach($product_page as $sp):?>
            <tr>
                <td><?=$sp['id']?></td>
                <td><?=$sp['name']?></td>
                <td><?=$sp['price']?></td>
                <td><?=$sp['saleprice']?></td>
                <td><img src="../layout/assets/imgages/products/<?=$sp['img']?>" width="60px" alt=""></td>
                <td><?=$sp['ten_dm']?></td>
                <td><?=$sp['soluong']?></td>
                <td><?=$sp['trangthai']?></td>
                <td><?=$sp['ngaynhap']?></td>
                <td>
                    <a href="?page=product&act=edit&id=<?=$sp['id']?>" class="btn btn-success">Edit</a>
                    <a href="?page=product&act=delete&id=<?=$sp['id']?>" class="btn btn-danger">Delete</a>
                </td>
            </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
    <!-- danh sách sản phẩm có phân trang -->
    <nav aria-label="Page navigation example" class="d-flex justify-content-center">
        <ul class="pagination">
            <?php for($i=1;$i<=$number_page;$i++):?>
            <li class="page-item"><a class="page-link" href="?page=product&act=list&page=<?=$i?>"><?=$i?></a></li>
            <!-- $page ở đây ko có giá trị nên null, -->
            <?php endfor; ?>
        </ul>
    </nav>


</div>