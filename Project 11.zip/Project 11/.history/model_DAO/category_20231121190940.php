<?php
       include_once 'modal/connect.php';

    
    function category_list(){
        $sql="SELECT * FROM danhmuc";
        return pdo_query($sql);
    }
    function category_add($name,$img,$status){
        $sql="INSERT INTO danhmuc(name,img,trangthai) VALUE (?,?,?) ";
        return pdo_execute($sql,$name,$img,$status);
    }
    function get_category_one($id){
        $sql="SELECT * FROM danhmuc WHERE id=?";
        return pdo_query_one($sql,$id);
    }
    function category_edit($name,$img,$status,$id){
        $sql="UPDATE danhmuc SET name=?, img=?, trangthai=? WHERE id=? ";
        return pdo_execute($sql,$name,$img,$status,$id);
    }
    function category_delete($id){
        $sql= "DELETE FROM danhmuc WHERE id=? ";
        return pdo_execute($sql,$id);
    }
?>