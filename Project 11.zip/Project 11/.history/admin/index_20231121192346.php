<?php
    extract($_REQUEST);
    if(isset($page)){
        switch($page){
            case 'category':
                include_once 'admin/controller/category.php';
                break;
            case 'product':
                include_once 'admin/controller/product.php';
                break;
            case 'user':
                include_once 'admin/controller/user.php';
                break;
        }
        
    }else {include_once 'admin/controller/category.php';
    }
?>