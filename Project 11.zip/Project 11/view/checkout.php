<?php
if(isset($_SESSION['giohang'])&&is_array($_SESSION['giohang'])){
    $i = 0;
    $final_total=0;
    $format_final_total=0;
    foreach ($_SESSION['giohang'] as $item) {
        # code...
        extract($item);
        $format_price = number_format($price, 0, ',', '.');
        $total = $price*$qty;
        $final_total +=$total;
        $format_final_total = number_format($final_total, 0, ',', '.');
        $format_total = number_format($total, 0, ',', '.');
        $linkdetail = 'index.php?page=detail&idproduct='.$id;
        $delete = 'index.php?page=deletecart&index='.$i;
        $html_tien='<div  class="col-12 mb-60">
                                            <h4 class="checkout-title">Cart Total</h4>
                                            <div class="checkout-cart-total">

                                                <h4>Product    <span>Total</span></h4>
                                                
                                                
                                                <ul>
                                                    <li name="tenhh">'.$name.'<span >'.$format_price.'</span></li>
                                                 
                                                </ul>

                                                
                                                <h4 >Grand Total <span name="tongtien">'.$format_final_total.'</span></h4>

                                            </div>

                                        </div>';
    }
}

    if(isset($_SESSION['s_user'])&&(count($_SESSION['s_user'])>0)){
        extract($_SESSION['s_user']);
            $html_thongtin=' <div id="billing-form" class="mb-10">
            <h4 class="checkout-title">Billing Address</h4>
            <div class="row">
                
                <div class="col-md-12 col-12 mb-5">
                    <label>Full name*</label>
                    <input type="text" name="tenm" value='.$ten.' placeholder="Họ và tên">
                </div>
                
               
                <div class="col-md-12 col-12 mb-5">
                    <label>Phone no*</label>
                    <input type="text" name="usernamem" value='.$username.' placeholder="Số điện thoại">
                </div>
                <div class="col-12 mb-5">
                    <label>Address*</label>
                    <input type="text" name="diachim" value='.$diachi.' placeholder="Nhập địa chỉ">
                </div>
                <div class="col-12 mb-5">
                    <label>Hãng</label>
                    <input type="text" name="tenhh" value='.$name.' placeholder="Nhập địa chỉ">
                </div>
                <div class="col-12 mb-5">
                    <label>Giá</label>
                    <input type="text" name="tongtien" value='.$format_final_total.' placeholder="Nhập địa chỉ">
                </div>
                
                <div class="col-12 mb-5">
                    <div class="check-box">
                        <input type="checkbox" id="shiping_address" data-shipping>
                        <label for="shiping_address">Ship to Different Address</label>
                    </div>
                </div>

            </div>

        </div>
        <div id="shipping-form">
        
                                        <h4 class="checkout-title">Shipping Address</h4>

                                        <div class="row">

                                            <div class="col-md-12 col-12 mb-5">
                                                <label>Full name*</label>
                                                <input type="text" name="tenn" placeholder="Họ và tên">
                                            </div>
                                        
                                            <div class="col-md-12 col-12 mb-5">
                                                <label>Phone no*</label>
                                                <input type="text" name="usernamen" placeholder="Số điện thoại">
                                            </div>
                                            <div class="col-12 mb-5">
                                                <label>Address*</label>
                                                <input type="text" name="diachin" placeholder="Nhập địa chỉ">
                                            </div>
                                        </div>
                                    </div>
                                        <div class="ok">
    

        <h1>Hóa đơn</h1>
        <table>
            <tr>
                <th>Tên sản phẩm</th>
                <th>Số lượng</th>
                <th>Giá</th>
            </tr>
            <tr>
                <td><input  name="tenh" placeholder="'.$name.'" ></td>
                <td><input   placeholder="'.$qty.'" ></td>
                <td><input  name="tongtin" placeholder="'.$format_final_total.'" ></td>
            </tr>
        </table>

        <button  class="place-order btn btn-lg btn-round" name="muahang">Place order</button>
    </div>
                                    
        ';
        }else{
            $html_thongtin='
            <h1 style="color:red">Vui lòng đăng nhập để mua hàng </h1>
            <h1 style="color: red;"><a href="index.php?page=dangnhap"> "Đăng nhập"</a></h1>
        ';
        }
?>
    <style>
        
        body {
            font-family: Arial, sans-serif;
            margin: 20px;
        }
        
        h1, h2 {
            text-align: center;
        }
        
        .ok {
            max-width: 500px;
            margin: 0 auto;
        }
        
        label, input {
            
            display: block;
            margin-bottom: 10px;
        }
        
        table {
            width: 100%;
            border-collapse: collapse;
        }
        
        th, td {
            padding: 5px;
            border: 1px solid #ccc;
        }
        
        input[type="submit"] {
            
            margin-top: 10px;
            padding: 10px;
            background-color: #4CAF50;
            color: white;
            border: none;
            cursor: pointer;
        }
</style>  
<div
    class="checkout-section section pt-30 pt-lg-80 pt-md-70 pt-sm-60 pt-xs-50  pb-70 pb-lg-50 pb-md-40 pb-sm-30 pb-xs-20">
    <div class="container">
        <div class="row">
            <div class="col-12">

                <!-- Checkout Form Start-->
                <form action="index.php?page=muahang" class="checkout-form" method="post">
                    <div class="row row-40">
                        <div class="col-lg-7">
                            <!-- Billing Address -->
                            <?=$html_thongtin?>
                            <!-- <div id="billing-form" class="mb-10">
                                        <h4 class="checkout-title">Billing Address</h4>
                                        <div class="row">
                                            
                                            <div class="col-md-12 col-12 mb-5">
                                                <label>Full name*</label>
                                                <input type="text" value="" placeholder="Họ và tên">
                                            </div>
                                           
                                            <div class="col-md-12 col-12 mb-5">
                                                <label>Phone no*</label>
                                                <input type="text" value=""  placeholder="Số điện thoại">
                                            </div>
                                            <div class="col-12 mb-5">
                                                <label>Address*</label>
                                                <input type="text" value="" placeholder="Nhập địa chỉ">
                                            </div>
                                            <div class="col-12 mb-5">
                                                <div class="check-box">
                                                    <input type="checkbox" id="shiping_address" data-shipping>
                                                    <label for="shiping_address">Ship to Different Address</label>
                                                </div>
                                            </div>

                                        </div>

                                    </div> -->

                            <!-- Shipping Address -->
                            <!-- <div id="shipping-form">
                                        <h4 class="checkout-title">Shipping Address</h4>

                                        <div class="row">

                                            <div class="col-md-12 col-12 mb-5">
                                                <label>Full name*</label>
                                                <input type="text" placeholder="Họ và tên">
                                            </div>
                                        
                                            <div class="col-md-12 col-12 mb-5">
                                                <label>Phone no*</label>
                                                <input type="text" placeholder="Số điện thoại">
                                            </div>
                                            <div class="col-12 mb-5">
                                                <label>Address*</label>
                                                <input type="text" placeholder="Nhập địa chỉ">
                                            </div>
                                        </div>
                                    </div> -->
                        </div>
                        <div class="col-lg-5">
                            <div class="row">
                                <!-- Cart Total -->
                                <?=$html_tien?>
                                <!-- <div class="col-12 mb-60">
                                            <h4 class="checkout-title">Cart Total</h4>
                                            <div class="checkout-cart-total">

                                                <h4>Product <span>Total</span></h4>

                                                <ul>
                                                    <li>Teritory Quentily X 01 <span>$35.00</span></li>
                                                    <li>Adurite Silocone X 02 <span>$59.00</span></li>
                                                    <li>Baizidale Momone X 01 <span>$78.00</span></li>
                                                    <li>Makorone Cicile X 01 <span>$65.00</span></li>
                                                </ul>

                                                <p>Sub Total <span>$296.00</span></p>
                                                <p>Shipping Fee <span>$00.00</span></p>

                                                <h4>Grand Total <span>$296.00</span></h4>

                                            </div>

                                        </div> -->

                                <!-- Payment Method -->
                                

                            </div>
                        </div>

                    </div>
                </form>

            </div>
        </div>
    </div>
</div>