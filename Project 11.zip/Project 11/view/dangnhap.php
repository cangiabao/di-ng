<!--Login Register section start-->
<div class="login-register-section section pt-30 pt-lg-80 pt-md-70 pt-sm-60 pt-xs-50  pb-70 pb-lg-50 pb-md-40 pb-sm-30 pb-xs-20">
            <div class="container">
                <div class="row">
                   
                    <!--Register Form Start-->
                    <div class="col-md-6 col-sm-6">
                        <div class="customer-login-register register-pt-0">
                            <div class="form-register-title">
                                <h2>Đăng nhập </h2>
                            </div>
                            <div class="register-form">
                                <h2 style="color: red;">
                                    <?php
                                        if(isset( $_SESSION['tb_dangnhap'])&&( $_SESSION['tb_dangnhap']!="")) {
                                            echo  $_SESSION['tb_dangnhap'];
                                            unset  ($_SESSION['tb_dangnhap']);
                                        }
                                    ?>
                                </h2>
                                <form action="index.php?page=login" method="post">
                                    <div class="form-fild">
                                        <p><label>Tên đăng nhập<span class="required">*</span></label></p>
                                        <input name="username" value="" id="username" type="text">
                                    </div>
                                    <div class="form-fild">
                                        <p><label>Mật khẩu<span class="required">*</span></label></p>
                                        <input name="password" value="" id="password" type="password">
                                    </div>
                                    <div class="register-submit">
                                        <input type="submit" name="dangnhap" class="btn" value="Đăng nhập">
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                    <!--Register Form End-->
                </div>
            </div>
        </div>
        <!--Login Register section end-->