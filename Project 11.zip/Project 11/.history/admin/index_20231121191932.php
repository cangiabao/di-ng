<?php 
    session_start();
    ob_start();
    include 'controller/connect.php';
    include 'controller/user.php';
    include 'modal/products.php';
    include 'modal/danhmuc.php';
    include 'admin/index.php';

    include 'view/header.php';
    $dssp_hot=get_dssp_hot();
    $dssp_new=get_dssp_new();
    $dssp_best=get_dssp_best();
    if(isset($_GET['page'])&& $_GET['page']!=""){
        $page = $_GET['page'];
        switch($page){
            case 'shop':
                $dsdm=danhmuc_all();
                if(!isset($_GET['iddm'])){
                    $iddm=0;
                }else{
                    $iddm=$_GET['iddm'];
                }
                if(isset($_POST['timkiem'])&&($_POST['timkiem'])){
                    $kyw=$_POST['kyw'];
                    $titlepage='Kết quả tìm kiếm với từ khóa: '.$kyw;
                }else{
                    $kyw='';
                    $titlepage='';
                }

                $dssp=get_dssp($kyw,$iddm);
                include "view/shop.php";
            break;
            case 'detail':
                if(isset($_GET['idproduct'])&&$_GET['idproduct']){
                    $id = $_GET['idproduct'];
                    $detailproduct = get_detail_product($id);
                    $iddm = $detailproduct['iddm'];
                    $relatedproduct =get_relate_products($iddm,$id);
                    $relatedsale =get_relate_sale($iddm,$id);
                    include 'view/detail.php';
                }else{

                }
                break;
            case 'cart':
                include 'view/cart.php';
                    break;
            case 'addtocart':
                if(isset($_POST['addtocart'])&&($_POST['addtocart'])){
                    $id = $_POST['id'];
                    $name = $_POST['name'];
                    $img = $_POST['img'];
                    $price = $_POST['price'];
                    $qty = $_POST['qty'];

                    $phone = ["id" => $id, "img" => $img, "name" => $name, "price" => $price, "qty" => $qty];
                    $_SESSION['giohang'][ ] = $phone;
                }
                header('location: index.php?page=cart');
                break;
                case 'deletecart':
                    if(isset($_GET['index'])&&$_GET['index']>=0){
                        array_splice($_SESSION['giohang'], $_GET['index'], 1);
                    }
                    header('location: index.php?page=cart');
                        break;

                              // Login/ logout
            case 'login':
                // input
                if(isset($_POST["login"])){
                    $username=$_POST["username"];
                    $password=$_POST["password"];
                // xl: KIỂM TRA
                    $kq=checkuser($username,$password);
                    if(is_array($kq)&&(count($kq))){
                        $_SESSION['s_user']=$kq;
                        header('location: index.php');
                    }else{
                        $tb="Tài khoản không tồn tại hoặc bạn đã nhập sai!";
                        $_SESSION['tb_dangnhap']=$tb;
                        header('location: index.php?page=dangnhap');
                    }
                // out
                // header('location: index.php');
                }
                break;
            case 'logout':
              if  (isset($_POST['thoat'])){
unset($_SESSION['username']);
unset($_SESSION['password']);
unset($_SESSION['s_user']);
header('location: dangnhap.php');
                };
            case 'dangnhap':
                include 'view/dangnhap.php';
                break;
            case 'adduser':
                if(isset($_POST['dangky'])){
                    $username=$_POST['username'];
                    $password=$_POST['password'];
                    $password2=$_POST['password2'];
                    user_insert($username, $password, $password2);
                }             
                include 'view/dangnhap.php';
                break;
            case 'updateuser':
                if(isset($_POST['capnhap'])){
                    $username=$_POST['username'];
                    $password=$_POST['password'];
                    $diachi=$_POST['diachi'];
                    $ten=$_POST['ten'];
                    $id=$_POST['id'];
                    $role=0;
                    user_update($username, $password, $diachi,$ten,$role,$id);
                    include 'view/myaccount_confirm.php';
                }             
                break;

            case 'dangky':
                    include 'view/dangky.php';
                        break;
            case 'myaccount':
                if(isset($_SESSION['s_user'])){
                    include "view/myaccount.php";
                }
                break;
                case 'admin':
                    include 'admin/index.php';
                    break;
                default:
            // $show_products = get_products(10);
            // $dssp=get_dssp($kyw,$iddm);
            include_once "view/home.php";
            break;
            case 'category':
                include_once 'admin/controller/category.php';
                break;
            case 'product':
                include_once 'admin/controller/product.php';
                break;
        }
        
    }else{
        // $show_products = get_products(10);
        // $dssp=get_dssp();
        include "view/home.php";
    }
    include_once 'view/footer.php';
?>