<?php
    if(isset($_SESSION['s_user'])&&(count($_SESSION['s_user'])>0)){
        extract($_SESSION['s_user']);
    }
?>
<div class="col-md-6 col-sm-6" style="justify-content: center; align-items: center;" >
                        <div class="customer-login-register register-pt-0">
                            <div class="form-register-title">
                                <h2>Cập nhập thông tin</h2>
                            </div>
                            <div class="register-form">
                                <form action="index.php?page=updateuser" method="post">
                                    <div class="form-fild">
                                        <p><label>số điện thoại<span class="required">*</span></label></p>
                                        <input name="username" value="<?=$name?>" type="text">
                                    </div>
                                    <div class="form-fild">
                                        <p><label>Mật khẩu<span class="required">*</span></label></p>
                                        <input name="password" value="<?=$pass?>" type="password">
                                    </div>
                                    <div class="form-fild">
                                        <p><label>Địa chỉ<span class="required">*</span></label></p>
                                        <input name="diachi" value="" type="text">
                                    </div>
                                    <div class="form-fild">
                                        <p><label>Tên<span class="required">*</span></label></p>
                                        <input name="ten" value="" type="text">
                                    </div>
                                    <div class="form-fild">
                                        <input name="id" value="" type="hidden" value="<?=$id?>">
                                    </div>
                                    <div class="register-submit">
                                        <button name="capnhap" type="submit" class="btn">Cập nhập</button>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>