<?php

function user_insert($username, $password, $ten){
    $sql = "INSERT INTO khachhang(username, password, ten) VALUES (?, ?, ?)";
    pdo_execute($sql, $username, $password, $ten);
}

function user_insert_id($username,$password,$ten,$diachi){
    $sql = "INSERT INTO khachhang(username,password,ten, diachi) VALUES (?,?,?, ?)";
    return pdo_execute_id($sql,$username,$password, $ten, $diachi);
}

function user_update($username, $password, $diachi,$ten, $role,$id ){
    $sql = "UPDATE khachhang SET username=?, password=?, diachi=?, ten=?, role=? WHERE id=? ";
    pdo_execute($sql, $username, $password, $diachi,$ten,$role,$id);

};

function checkuser($username, $password){
    $sql="Select * from khachhang where username=? and password=?";
    return pdo_query_one($sql, $username, $password);
   
}
function checkemail($username){
    $sql="Select * from khachhang where username='".$username."'";
    return pdo_query_one($sql);
    
}

function get_user($id){
    $sql="Select * from khachhang where id=?";
    return pdo_query_one($sql, $id);
}
function muahang($tenhh,$tongtien,$tenm, $usernamem,$diachim,$tenn, $usernamen,$diachin){
    $sql = "INSERT INTO chitietdonhang(tenhh,tongtien,tenm,usernamem,diachim,tenn,usernamen,diachin) VALUES (?, ?, ?,?,?,?,?,?)";
    pdo_execute($sql, $tenhh,$tongtien,$tenm, $usernamem,$diachim,$tenn, $usernamen,$diachin);
}

?>