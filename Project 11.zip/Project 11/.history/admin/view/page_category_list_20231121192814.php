<div class="p-5 vh-100">
    <h3 class="text-center">Quản lý danh mục</h3>
    <div >
        <a class="btn btn-primary" href="?page=category&act=add">Thêm danh mục</a>
    </div>
    
    <table class="table table-hover ">
        <thead>
            <tr>
                <th>Mã danh mục</th>
                <th>Tên danh mục</th>
                <th>Hình ảnh</th>
                <th>Trạng thái</th>
                <th>Thao tác</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach($dsdm as $dm): ?>
            <tr>
                <td><?=$dm['id']?></td>
                <td><?=$dm['name']?></td>
                <td><img src="../layout/assets/imgages/products/<?=$dm['img']?>" width="120px" alt=""></td>
                <td><?=$dm['trangthai']?></td>
                <td>
                    <a class="btn btn-primary" href="?page=category&act=edit&id=<?=$dm['id']?>">Sửa</a>
                    <a class="btn btn-danger" href="?page=category&act=delete&id=<?=$dm['id']?>">Xóa</a>
            </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</div>