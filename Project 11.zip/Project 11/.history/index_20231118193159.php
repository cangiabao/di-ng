<?php 
    session_start();
    ob_start();
    include 'controller/connect.php';
    include 'modal/products.php';
    include 'modal/danhmuc.php';

    include 'view/header.php';
    $dssp_hot=get_dssp_hot();
    $dssp_new=get_dssp_new();
    $dssp_best=get_dssp_best();
    if(isset($_GET['page'])&& $_GET['page']!=""){
        $page = $_GET['page'];
        switch($page){
            case 'shop':
                $dsdm=danhmuc_all();
                if(!isset($_GET['iddm'])){
                    $iddm=0;
                }else{
                    $iddm=$_GET['iddm'];
                }
                if(isset($_POST['timkiem'])&&($_POST['timkiem'])){
                    $kyw=$_POST['kyw'];
                    $titlepage='Kết quả tìm kiếm với từ khóa: '.$kyw;
                }else{
                    $kyw='';
                    $titlepage='';
                }

                $dssp=get_dssp($kyw,$iddm);
                include "view/shop.php";
            break;
            case 'detail':
                include 'view/detail.php';
                break;
            case 'cart':
                include 'view/cart.php';
                    break;
            case 'addtocart':
                if(isset($_POST['addtocart'])&&($_POST['addtocart'])){
                    $id = $_POST['id'];
                    $name = $_POST['name'];
                    $img = $_POST['img'];
                    $price = $_POST['price'];
                    $qty = $_POST['qty'];

                    $phone = ["id" => $id, "img" => $img, "name" => $name, "price" => $price, "qty" => $qty];
                    $_SESSION['giohang'][ ] = $phone;
                }
                header('location: index.php?page=cart');
                break;
                case 'deletecart':
                    if(isset($_GET['index'])&&$_GET['index']>=0){
                        array_splice($_SESSION['giohang'], $_GET['index'], 1);
                    }
                    header('location: index.php?page=cart');
                        break;
                default:
            // $show_products = get_products(10);
            // $dssp=get_dssp($kyw,$iddm);
            include_once "view/home.php";
            break;
        }
    }else{
        // $show_products = get_products(10);
        // $dssp=get_dssp();
        include "view/home.php";
    }


    include 'view/footer.php';
?>