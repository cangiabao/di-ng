<?php
    $html_dm=showdm($dsdm);
    if($titlepage!='') {
        $title=$titlepage;
    }else{
        $title="Products";
    }
    $html_dssp='';
    foreach ($dssp as $sp) {
        extract($sp);
        $format_price = number_format($price, 0, ',', '.');
        $format_saleprice = number_format($saleprice, 0, ',', '.');
        if($saleprice > 0){
            $oldprice = ' <h4 class="price"><span class="old" style="text-decoration: line-through">'. $format_price.' VND</span>
            <br>
            <span class="new">'.$format_saleprice.' VND</span></h4>';
        }else{
            $oldprice= '<h4 class="price"><span class="new">'.$format_price.' VND</span></h4>';
        }
        if($discount > 0 ){
            $percent = '<span class="descount-sticker">-'.$discount.'%</span>';
        }else{
            $percent = '';
        }
        if($new == 1 ){
            $new_label = '<span class="sticker">New</span>';
        }else{
            $new_label = '';
        }
        $linkdetail='index.php?page=detail&idproduct='.$id;
        $html_dssp.='<div class="col-lg-4 col-md-6 col-sm-6">
                        <!-- Single Product Start -->
                        <div class="single-product mb-30">
                        <div class="product-img">
                            <a href="'.$linkdetail.'">
                                <img src="./layout/assets/images/products/'.$img.'" alt="">
                            </a>
                            '.$percent.'
                            '.$new_label.'
                            <div class="product-action d-flex justify-content-between">
                            <form action="index.php?page=addtocart" method="post">
                                <input type="hidden" name="id" value="'.$id.'">
                                <input type="hidden" name="name" value="'.$name.'">
                                <input type="hidden" name="img" value="'.$img.'">
                                <input type="hidden" name="price" value="'.$price.'">
                                <input type="hidden" name="qty" value="1">
        
                                <input class="product-btn" type= "submit" name="addtocart" value= "Add to Cart">
                            </form>
                                <ul class="d-flex">
                                    <li><a href="#quick-view-modal-container" data-toggle="modal"
                                            title="Quick View"><i class="fa fa-eye"></i></a></li>
                                    <li><a href="#"><i class="fa fa-heart-o"></i></a></li>
                                    <li><a href="#"><i class="fa fa-exchange"></i></a></li>
                                </ul>
                            </div>
                        </div>
                        <div class="product-content">
                            <h3><a href="single-product.html">'.$name.'</a></h3>
                            <div class="ratting">
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star"></i>
                            </div>
                            '.$oldprice.'
                        </div>
                    </div>
                    </div>';
    }
?>

<div class="page-banner-section section bg-gray">
            <div class="container">
                <div class="row">
                    <div class="col">
                        <div class="page-banner text-center">
                            <h1 style="margin: 0 !important;"><?=$title?></h1>
                            <ul class="page-breadcrumb">
                                <li><a href="index.html">Home</a></li>
                                <li>Shop</li>
                            </ul>
                        </div>

                    </div>
                </div>
            </div>
        </div>
        <div
            class="shop-section section pt-30 pt-lg-80 pt-md-70 pt-sm-60 pt-xs-50 pb-70 pb-lg-50 pb-md-40 pb-sm-60 pb-xs-50">
            <div class="container">
                <div class="row">
                    <div class="col-lg-3 order-lg-1 order-2">
                        <!-- Single Sidebar Start  -->
                        <div class="common-sidebar-widget">
                            <h3 class="sidebar-title">Categories</h3>
                            
                            <ul class="sidebar-list">
                                <?=$html_dm;?>
                               
                            </ul>
                        </div>
                        <!-- Single Sidebar End  -->
                        <!-- Single Sidebar Start  -->
                        
                        <!-- Single Sidebar End  -->
                        <!-- Single Sidebar Start  -->
                        <div class="common-sidebar-widget">
                            <div class="single-banner">
                                <a href="#">
                                    <img src="assets/images/banner/h4-banner-2.png" alt="">
                                </a>
                            </div>
                        </div>
                        <!-- Single Sidebar End  -->
                    </div>
                    <div class="col-lg-9 order-lg-2 order-1">
                       
                        <div class="row">
                            <div class="col-12">
                                <!-- Grid & List View Start -->
                                <div
                                    class="shop-topbar-wrapper d-md-flex justify-content-md-between align-items-center">
                                    <div class="grid-list-option">

                                    </div>
                                    <!--Toolbar Short Area Start-->
                                    <div class="toolbar-short-area d-md-flex align-items-center">
                                        <div class="toolbar-shorter ">
                                            <label>Sort By:</label>
                                            <select class="wide">
                                                <option data-display="Select">Nothing</option>
                                                <option value="Relevance">Relevance</option>
                                                <option value="Name, A to Z">Name, A to Z</option>
                                                <option value="Name, Z to A">Name, Z to A</option>
                                                <option value="Price, low to high">Price, low to high</option>
                                                <option value="Price, high to low">Price, high to low</option>
                                            </select>
                                        </div>
                                        <div class="toolbar-shorter ">
                                            <label>Show</label>
                                            <select class="small">
                                                <option data-display="Select">9</option>
                                                <option value="15">15</option>
                                                <option value="30">30</option>
                                            </select>
                                            <span>per page</span>
                                        </div>

                                    </div>
                                    <!--Toolbar Short Area End-->
                                </div>
                                <!-- Grid & List View End -->
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-12">
                                <div class="shop-product">
                                    <div id="myTabContent-2" class="tab-content">
                                        <div id="grid" class="tab-pane fade active show">
                                            <div class="product-grid-view">
                                                <div class="row">
                                                    
                                                    <?=$html_dssp;?>
                                                </div>
                                            </div>
                                        </div>
                                        <div id="list" class="tab-pane fade">
                                            <div class="product-list-view">       
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="row mb-30 mb-sm-40 mb-xs-30">
                            <div class="col">
                                <ul class="page-pagination">
                                    <li><a href="#"><i class="fa fa-angle-left"></i></a></li>
                                    <li class="active"><a href="#">01</a></li>
                                    <li><a href="#">02</a></li>
                                    <li><a href="#">03</a></li>
                                    <li><a href="#"><i class="fa fa-angle-right"></i></a></li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- Shop Section End -->