
<div class="page-banner-section section bg-gray">
            <div class="container">
                <div class="row">
                    <div class="col">
                        <div class="page-banner text-center">
                            <h1>Shopping Cart</h1>
                            <ul class="page-breadcrumb">
                                <li><a href="index.html">Home</a></li>
                                <li>Cart</li>
                            </ul>
                        </div>

                    </div>
                </div>
            </div>
        </div>
        <!--Cart section start-->
        <div
            class="cart-section section pt-30 pt-lg-80 pt-md-70 pt-sm-60 pt-xs-50  pb-70 pb-lg-50 pb-md-40 pb-sm-30 pb-xs-20">
            <div class="container">
                <div class="row">

                    <div class="col-12">
                        <!-- Cart Table -->
                        <div class="cart-table table-responsive mb-30">
                            <table class="table">
                                <thead>
                                    <tr>
                                        <th class="pro-thumbnail">Image</th>
                                        <th class="pro-title">Product</th>
                                        <th class="pro-price">Price</th>
                                        <th class="pro-quantity">Quantity</th>
                                        <th class="pro-subtotal">Total</th>
                                        <th class="pro-remove">Remove</th>
                                    </tr>
                                </thead>
                                <tbody>
                            <?php 
                                        if(isset($_SESSION['giohang'])&&is_array($_SESSION['giohang'])){
                                            $i = 0;
                                            foreach ($_SESSION['giohang'] as $item) {
                                                # code...
                                                extract($item);
                                                $format_price = number_format($price, 0, ',', '.');
                                                $total = $price*$qty;
                                                $final_total+= $total;
                                                $format_final_total= number_format($final_total, 0, ',', '.');
                                                $format_total = number_format($total, 0, ',', '.');
                                                $linkdetail = 'index.php?page=detail&idproduct='.$id;
                                                $delete = 'index.php?page=deletecart&index='.$i;
                                                echo '
                                                <tr>
                                                <td class="pro-thumbnail"><a href="'.$linkdetail.'"><img
                                                            src="layout/assets/images/products/'.$img.'" alt="Product"></a></td>
                                                <td class="pro-title"><a href="'.$linkdetail.'">'.$name.'</a></td>
                                                <td class="pro-price"><span>'.$format_price.'</span></td>
                                                <td class="pro-quantity">
                                                    <div class="pro-qty"><input type="number" value="'.$qty.'"></div>
                                                </td>
                                                <td class="pro-subtotal"><span>'.$format_total.'</span></td>
                                                <td class="pro-remove"><a href="'.$delete.'"><i class="fa fa-trash-o"></i></a></td>
                                            </tr>
                                                ';
                                                $i++;
                                            }
        }
                                ?>
                                </tbody>
                                <tfoot>
                                    <tr>
                                        <td colspan="4" class="text-left">
                                        <div class="cart-summary-button">
                                        <a style="color: #fff;" class="btn" href="index.php?page=shop">Continue buying</a>
                                            </div>
                                        </td>
                                        <td colspan="4" class="text-left" >
                                            <h4 style="line-height: 45px;">Total:</h4>
                                        </td>
                                        <td class="text-left"><h4 style="line-height: 45px;"><?=$format_final_total?> VND</h4></td>
                                        <td class="text-right">
                                            <div class="cart-summary-button">
                                                <a style="color: #fff;" class="btn" href="index.php?page=checkout">Checkout</a>
                                            </div>
                                        </td>
                                    </tr>
                                </tfoot>
                            </table>
                        </div>
                        

                    </div>

                </div>
            </div>
        </div>
        <!--Cart section end-->
        <input type="submit" value="">
        <!--Brand section start-->
        <div
            class="brand-section section border-top pt-90 pt-lg-70 pt-md-65 pt-sm-55 pt-xs-40 pb-100 pb-lg-80 pb-md-70 pb-sm-60 pb-xs-50">
            <div class="container">
                <div class="row">

                    <!--Brand Slider start-->
                    <div class="tf-element-carousel section" data-slick-options='{
                "slidesToShow": 5,
                "slidesToScroll": 1,
                "infinite": true,
                "arrows": false,
                "autoplay": true
                }' data-slick-responsive='[
                {"breakpoint":1199, "settings": {
                "slidesToShow": 4
                }},
                {"breakpoint":992, "settings": {
                "slidesToShow": 4
                }},
                {"breakpoint":768, "settings": {
                "slidesToShow": 3
                }},
                {"breakpoint":576, "settings": {
                "slidesToShow": 1
                }}
                ]'>
                        <div class="brand col"><a href="#"><img src="assets/images/brands/brand-1.png" alt=""></a></div>
                        <div class="brand col"><a href="#"><img src="assets/images/brands/brand-2.png" alt=""></a></div>
                        <div class="brand col"><a href="#"><img src="assets/images/brands/brand-3.png" alt=""></a></div>
                        <div class="brand col"><a href="#"><img src="assets/images/brands/brand-4.png" alt=""></a></div>
                        <div class="brand col"><a href="#"><img src="assets/images/brands/brand-5.png" alt=""></a></div>
                    </div>
                    <!--Brand Slider end-->

                </div>
            </div>
        </div>
        <!--Brand section end-->