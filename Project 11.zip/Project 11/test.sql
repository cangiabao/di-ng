-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 13, 2023 at 03:16 PM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.0.28

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `test`
--

-- --------------------------------------------------------

--
-- Table structure for table `bill`
--

CREATE TABLE `bill` (
  `id` int(9) NOT NULL,
  `madh` varchar(50) NOT NULL,
  `iduser` int(6) NOT NULL,
  `nguoidat_ten` varchar(50) NOT NULL,
  `nguoidat_email` varchar(50) NOT NULL,
  `nguoidat_tel` varchar(20) NOT NULL,
  `nguoidat_diachi` varchar(100) NOT NULL,
  `nguoinhan_ten` varchar(50) DEFAULT NULL,
  `nguoinhan_diachi` varchar(100) DEFAULT NULL,
  `nguoinhan_tel` varchar(20) DEFAULT NULL,
  `total` int(9) NOT NULL,
  `ship` int(6) NOT NULL DEFAULT 0,
  `voucher` int(6) NOT NULL DEFAULT 0,
  `tongthanhtoan` int(9) NOT NULL,
  `pttt` tinyint(1) NOT NULL COMMENT '0: COD; 1: ck; 2: ví điện tử'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `bill`
--

INSERT INTO `bill` (`id`, `madh`, `iduser`, `nguoidat_ten`, `nguoidat_email`, `nguoidat_tel`, `nguoidat_diachi`, `nguoinhan_ten`, `nguoinhan_diachi`, `nguoinhan_tel`, `total`, `ship`, `voucher`, `tongthanhtoan`, `pttt`) VALUES
(1, 'Zhope10-154741-11102023', 10, 'dasdsasd', 'nghia@gmail.com', '0916255152', 'sai gon', '', '', '', 110, 0, 0, 110, 1),
(2, 'Zhope11-155319-11102023', 11, 'dasdsasd', 'nghia@gmail.com', '0916255152', 'sai gon', '', '', '', 110, 0, 0, 110, 1),
(3, 'Zhope12-155753-11102023', 12, 'dasdsasd', 'nghia@gmail.com', '0916255152', 'sai gon', '', '', '', 110, 0, 0, 110, 1),
(4, 'Zhope13-161448-11102023', 13, 'dasdsasd', 'nghia@gmail.com', '0916255152', 'sai gon', '', '', '', 110, 0, 0, 110, 1),
(5, 'Zhope14-161545-11102023', 14, 'dasdsasd', 'nghia@gmail.com', '0916255152', 'sai gon', '', '', '', 110, 0, 0, 110, 1),
(6, 'Zhope15-161654-11102023', 15, '', '', '', '', '', '', '', 110, 0, 0, 110, 1),
(7, 'Zhope16-161743-11102023', 16, 'dasdsasd', 'nghia@gmail.com', '0916255152', 'sai gon', '', '', '', 110, 0, 0, 110, 1),
(8, 'Zhope17-161842-11102023', 17, 'dasdsasd', 'nghia@gmail.com', '0916255152', 'sai gon', '', '', '', 110, 0, 0, 110, 1),
(9, 'Zhope19-162421-11102023', 19, 'dasdsasd', 'nghia@gmail.com', '0916255152', 'sai gon', '', '', '', 110, 0, 0, 110, 1),
(10, 'Zhope20-162511-11102023', 20, 'dasdsasd', 'nghia@gmail.com', '0916255152', 'sai gon', '', '', '', 220, 0, 0, 220, 1),
(11, 'Zhope22-031608-18102023', 22, '', '', '', '', '', '', '', 999, 0, 0, 999, 1),
(12, 'Zhope23-031626-18102023', 23, '', '', '', '', '', '', '', 999, 0, 0, 999, 1),
(13, 'Zhope24-031642-18102023', 24, '', '', '', '', '', '', '', 999, 0, 0, 999, 1),
(14, 'Zhope25-163456-18102023', 25, 'dasdsasd', '', '', '', '', '', '', 0, 0, 0, 0, 1),
(15, 'Zhope26-163558-18102023', 26, '', '', '', '', '', '', '', 999, 0, 0, 999, 1),
(16, 'Zhope27-165219-18102023', 27, '', '', '', '', '', '', '', 0, 0, 0, 0, 1),
(17, 'Zhope28-165833-18102023', 28, '', '', '', '', '', '', '', 0, 0, 0, 0, 1),
(18, 'Zhope29-165843-18102023', 29, '', '', '', '', '', '', '', 0, 0, 0, 0, 1),
(19, 'Zhope30-165847-18102023', 30, '', 'nghia@gmail.com', '0916255152', 'sai gon', '', '', '', 0, 0, 0, 0, 1),
(20, 'Zhope31-165856-18102023', 31, '', 'nghia@gmail.com', '0916255152', 'sai gon', '', '', '', 0, 0, 0, 0, 1),
(21, 'Zhope32-165906-18102023', 32, '', '', '', '', '', '', '', 0, 0, 0, 0, 1),
(22, 'Zhope33-170014-18102023', 33, '', '', '', '', '', '', '', 0, 0, 0, 0, 1),
(23, 'Zhope34-170019-18102023', 34, '', '', '', '', '', '', '', 0, 0, 0, 0, 1),
(24, 'Zhope35-170023-18102023', 35, '', 'nghia@gmail.com', '0916255152', 'sai gon', '', '', '', 0, 0, 0, 0, 1),
(25, 'Zhope36-170025-18102023', 36, '', '', '', '', '', '', '', 0, 0, 0, 0, 1),
(26, 'Zhope37-170028-18102023', 37, '', '', '', '', '', '', '', 0, 0, 0, 0, 1),
(27, 'Zhope38-170240-18102023', 38, '', '', '', '', '', '', '', 0, 0, 0, 0, 1),
(28, 'Zhope39-170246-18102023', 39, '', '', '', '', '', '', '', 0, 0, 0, 0, 1),
(29, 'Zhope40-171325-18102023', 40, '', '', '', '', '', '', '', 0, 0, 0, 0, 1),
(30, 'Zhope41-171330-18102023', 41, '', '', '', '', '', '', '', 0, 0, 0, 0, 1),
(31, 'Zhope42-171343-18102023', 42, '', '', '', '', '', '', '', 0, 0, 0, 0, 1),
(32, 'Zhope43-172020-18102023', 43, 'dasdsasd', 'nghia@gmail.com', '0916255152', 'sai gon', '', '', '', 0, 0, 0, 0, 1),
(33, 'Zhope44-173105-18102023', 44, '', '', 'đâsdsafsdfsdfds', '', '', '', '', 0, 0, 0, 0, 2),
(34, 'Zhope45-173127-18102023', 45, '', '', '', '', '', '', '', 0, 0, 0, 0, 1),
(35, 'Zhope46-173203-18102023', 46, '', '', '', '', '', '', '', 0, 0, 0, 0, 1),
(36, 'Zhope47-173247-18102023', 47, '', '', '', '', '', '', '', 0, 0, 0, 0, 1),
(37, 'Zhope48-173351-18102023', 48, '', '', '', '', '', '', '', 0, 0, 0, 0, 1),
(38, 'Zhope49-173431-18102023', 49, '', '', 'ádasds', '', '', '', '', 0, 0, 0, 0, 1),
(39, 'Zhope50-180928-18102023', 50, '', '', 'ádasdasd', '', '', '', '', 1998, 0, 0, 1998, 1),
(40, 'Zhope51-181027-18102023', 51, '', '', 'ads', '', '', '', '', 1998, 0, 0, 1998, 1),
(41, 'Zhope52-181149-18102023', 52, '', '', 'ÂSADSAD', '', '', '', '', 1998, 0, 0, 1998, 1),
(42, 'Zhope53-181514-18102023', 53, '', '', '', '', '', '', '', 0, 0, 0, 0, 1),
(43, 'Zhope54-181653-18102023', 54, '', '', 'ADSFD', '', '', '', '', 0, 0, 0, 0, 1),
(44, 'Zhope55-181710-18102023', 55, '', '', '', '', '', '', '', 0, 0, 0, 0, 1),
(45, 'Zhope56-181941-18102023', 56, '', '', '', '', '', '', '', 0, 0, 0, 0, 1),
(46, 'Zhope57-181941-18102023', 57, '', '', '', '', '', '', '', 0, 0, 0, 0, 1),
(47, 'Zhope58-181948-18102023', 58, '', '', '', '', '', '', '', 0, 0, 0, 0, 1),
(48, 'Zhope59-182113-18102023', 59, '', '', '', '', '', '', '', 0, 0, 0, 0, 1),
(49, 'Zhope60-182119-18102023', 60, '', '', '', '', '', '', '', 0, 0, 0, 0, 1),
(50, 'Zhope61-182135-18102023', 61, '', '', '', '', '', '', '', 0, 0, 0, 0, 1),
(51, 'Zhope62-182201-18102023', 62, '', '', '', '', '', '', '', 0, 0, 0, 0, 1),
(52, 'Zhope63-182248-18102023', 63, '', '', '00', '', '', '', '', 0, 0, 0, 0, 1),
(53, 'Zhope64-182254-18102023', 64, '', '', '', '', '', '', '', 0, 0, 0, 0, 1),
(54, 'Zhope65-182307-18102023', 65, '', '', '', '', '', '', '', 0, 0, 0, 0, 1),
(55, 'Zhope66-182536-18102023', 66, '', '', '', '', '', '', '', 0, 0, 0, 0, 1),
(56, 'Zhope67-182555-18102023', 67, '', '', 'SÁ', '', '', '', '', 0, 0, 0, 0, 1),
(57, 'Zhope68-182637-18102023', 68, '', 'nghia@gmail.com', '0916255152', 'sai gon', '', '', '', 0, 0, 0, 0, 1),
(58, 'Zhope69-182724-18102023', 69, '', '', 'ádas', '', '', '', '', 0, 0, 0, 0, 1),
(59, 'Zhope70-182732-18102023', 70, '', '', 'ádas', '', '', '', '', 0, 0, 0, 0, 1),
(60, 'Zhope71-182906-18102023', 71, '', '', '', '', '', '', '', 0, 0, 0, 0, 1),
(61, 'Zhope72-182934-18102023', 72, '', '', '', '', '', '', '', 0, 0, 0, 0, 1),
(62, 'Zhope73-182947-18102023', 73, '', '', '', '', '', '', '', 0, 0, 0, 0, 1),
(63, 'Zhope74-183225-18102023', 74, '', 'nghia@gmail.com', '0916255152', 'sai gon', '', '', '', 999, 0, 0, 999, 1);

-- --------------------------------------------------------

--
-- Table structure for table `binhluan`
--

CREATE TABLE `binhluan` (
  `id` int(10) NOT NULL,
  `noidung` varchar(255) NOT NULL,
  `iduser` int(6) NOT NULL,
  `idpro` int(10) NOT NULL,
  `ngaybinhluan` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `binhluan`
--

INSERT INTO `binhluan` (`id`, `noidung`, `iduser`, `idpro`, `ngaybinhluan`) VALUES
(4, 'nghia', 0, 14, '06:14:01pm 14/10/2023'),
(5, 'sád', 0, 18, '06:32:36pm 18/10/2023');

-- --------------------------------------------------------

--
-- Table structure for table `cart`
--

CREATE TABLE `cart` (
  `id` int(6) NOT NULL,
  `idpro` int(6) NOT NULL,
  `price` int(6) NOT NULL,
  `name` varchar(100) NOT NULL,
  `img` varchar(200) NOT NULL,
  `soluong` int(3) NOT NULL,
  `idbill` int(6) NOT NULL,
  `thanhtien` int(6) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `cart`
--

INSERT INTO `cart` (`id`, `idpro`, `price`, `name`, `img`, `soluong`, `idbill`, `thanhtien`) VALUES
(1, 16, 110, 'Nike Tanjun EasyOn', 'kid5.webp', 1, 10, 110),
(2, 18, 110, 'Nike Tanjun EasyOn\r\n', 'kid5.webp', 1, 10, 110),
(3, 16, 999, 'Nike Tanjun EasyOn', 'kid5.webp', 1, 15, 999),
(7, 16, 999, 'Nike Tanjun EasyOn', 'kid5.webp', 1, 63, 999);

-- --------------------------------------------------------

--
-- Table structure for table `danhmuc`
--

CREATE TABLE `danhmuc` (
  `id` int(3) NOT NULL,
  `name` varchar(50) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `danhmuc`
--

INSERT INTO `danhmuc` (`id`, `name`) VALUES
(1, 'Nam'),
(2, '1234'),
(3, 'Trẻ em');

-- --------------------------------------------------------

--
-- Table structure for table `product`
--

CREATE TABLE `product` (
  `id` int(5) NOT NULL,
  `name` varchar(100) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `img` varchar(100) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `price` double(10,2) NOT NULL DEFAULT 0.00,
  `price2` double(10,2) NOT NULL DEFAULT 0.00,
  `new` tinyint(1) NOT NULL DEFAULT 0,
  `view` tinyint(1) NOT NULL DEFAULT 0,
  `idcatalog` int(3) NOT NULL,
  `promotion` int(3) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `product`
--

INSERT INTO `product` (`id`, `name`, `img`, `price`, `price2`, `new`, `view`, `idcatalog`, `promotion`) VALUES
(1, 'Nike Air Force 1', 'nike1.webp', 999.00, 499.00, 0, 0, 1, 0),
(2, 'Giày Thời Trang Nam Nike Air Max 270', 'nike2.webp', 999.00, 599.00, 0, 0, 1, 0),
(3, 'test', 'nike2.webp', 999.00, 599.00, 1, 0, 1, 0),
(4, 'Nike Dunk Low Retro', 'nike4.webp', 999.00, 699.00, 1, 0, 2, 0),
(5, 'Nike InfinityRN 4', 'nike9.webp', 999.00, 499.00, 0, 0, 2, 50),
(6, 'Nike Metcon 9 AMP', 'nike6.webp', 999.00, 499.00, 0, 0, 2, 0),
(7, 'Nike Air Max 90', 'nike7.webp', 999.00, 399.00, 0, 0, 2, 0),
(8, 'Nike Revolution 6', 'nike8.webp', 999.00, 699.00, 1, 0, 1, 50),
(9, 'Nike Pegasus 40', 'nike9.webp', 999.00, 499.00, 1, 0, 1, 50),
(10, 'Nike InfinityRN 4 SE\r\n', 'nike10.webp', 999.00, 699.00, 1, 0, 1, 50),
(11, 'Nike Dunk Low Retro', 'nike1.webp', 999.00, 899.00, 1, 0, 1, 50),
(12, 'Nike Flex Runner 2', 'nike9.webp', 999.00, 499.00, 0, 0, 3, 500),
(13, 'Nike Flex Runner 2', 'kid2.webp', 999.00, 499.00, 1, 0, 3, 0),
(14, 'Nike Pico 5', 'kid3.webp', 999.00, 519.00, 0, 0, 3, 50),
(15, 'Jordan 1 Low Alt', 'kid4.webp', 999.00, 699.00, 1, 0, 3, 50),
(16, 'Nike Tanjun EasyOn', 'kid5.webp', 999.00, 499.00, 1, 0, 3, 0),
(17, 'Nike Tanjun EasyOn\r\n', 'kid6.webp', 999.00, 499.00, 1, 0, 3, 50),
(18, 'Nike Tanjun EasyOn\r\n', 'kid5.webp', 999.00, 499.00, 1, 0, 3, 0),
(21, '', '', 0.00, 0.00, 0, 0, 1, 0);

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `id` int(6) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  `ten` varchar(50) DEFAULT NULL,
  `diachi` varchar(100) DEFAULT NULL,
  `email` varchar(50) NOT NULL,
  `dienthoai` varchar(20) DEFAULT NULL,
  `role` tinyint(1) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id`, `username`, `password`, `ten`, `diachi`, `email`, `dienthoai`, `role`) VALUES
(1, 'nghia2', '1234', NULL, 'tp hcm', 'nghia@gmail.com', '0987654321', 1),
(2, 'nghia', '12345', '', NULL, 'nghia@gmail.com', NULL, 0),
(4, 'guest654', '123456', NULL, 'tp hcm', 'nghia@gmail.com', '0987654321', 0),
(5, 'guest479', '123456', 'dasdsasd', 'tp hcm', 'nghia@gmail.com', '0987654321', 0),
(6, 'guest956', '123456', 'dasdsasd', 'tp hcm', 'nghia@gmail.com', '0987654321', 0),
(7, 'guest592', '123456', 'dasdsasd', 'tp hcm', 'nghia@gmail.com', '0987654321', 0),
(8, 'guest456', '123456', 'dasdsasd', 'tp hcm', 'nghia@gmail.com', '0987654321', 0),
(9, 'guest53', '123456', 'dasdsasd', 'tp hcm', 'nghia@gmail.com', '0987654321', 0),
(10, 'guest754', '123456', 'dasdsasd', 'sai gon', 'nghia@gmail.com', '0916255152', 0),
(11, 'guest233', '123456', 'dasdsasd', 'sai gon', 'nghia@gmail.com', '0916255152', 0),
(12, 'guest793', '123456', 'dasdsasd', 'sai gon', 'nghia@gmail.com', '0916255152', 0),
(13, 'guest361', '123456', 'dasdsasd', 'sai gon', 'nghia@gmail.com', '0916255152', 0),
(14, 'guest114', '123456', 'dasdsasd', 'sai gon', 'nghia@gmail.com', '0916255152', 0),
(15, 'guest860', '123456', '', '', '', '', 0),
(16, 'guest385', '123456', 'dasdsasd', 'sai gon', 'nghia@gmail.com', '0916255152', 0),
(17, 'guest957', '123456', 'dasdsasd', 'sai gon', 'nghia@gmail.com', '0916255152', 0),
(19, 'guest892', '123456', 'dasdsasd', 'sai gon', 'nghia@gmail.com', '0916255152', 0),
(20, 'guest104', '123456', 'dasdsasd', 'sai gon', 'nghia@gmail.com', '0916255152', 0),
(21, 'nghia123', '123', NULL, NULL, 'gauconpoq@gmail.com', NULL, 0),
(22, 'guest80', '123456', '', '', '', '', 0),
(23, 'guest683', '123456', '', '', '', '', 0),
(24, 'guest477', '123456', '', '', '', '', 0),
(25, 'guest563', '123456', 'dasdsasd', '', '', '', 0),
(26, 'guest576', '123456', '', '', '', '', 0),
(27, 'guest176', '123456', '', '', '', '', 0),
(28, 'guest927', '123456', '', '', '', '', 0),
(29, 'guest406', '123456', '', '', '', '', 0),
(30, 'guest234', '123456', '', 'sai gon', 'nghia@gmail.com', '0916255152', 0),
(31, 'guest810', '123456', '', 'sai gon', 'nghia@gmail.com', '0916255152', 0),
(32, 'guest456', '123456', '', '', '', '', 0),
(33, 'guest550', '123456', '', '', '', '', 0),
(34, 'guest475', '123456', '', '', '', '', 0),
(35, 'guest891', '123456', '', 'sai gon', 'nghia@gmail.com', '0916255152', 0),
(36, 'guest103', '123456', '', '', '', '', 0),
(37, 'guest192', '123456', '', '', '', '', 0),
(38, 'guest534', '123456', '', '', '', '', 0),
(39, 'guest488', '123456', '', '', '', '', 0),
(40, 'guest979', '123456', '', '', '', '', 0),
(41, 'guest600', '123456', '', '', '', '', 0),
(42, 'guest748', '123456', '', '', '', '', 0),
(43, 'guest249', '123456', 'dasdsasd', 'sai gon', 'nghia@gmail.com', '0916255152', 0),
(44, 'guest999', '123456', '', '', '', 'đâsdsafsdfsdfds', 0),
(45, 'guest716', '123456', '', '', '', '', 0),
(46, 'guest200', '123456', '', '', '', '', 0),
(47, 'guest567', '123456', '', '', '', '', 0),
(48, 'guest246', '123456', '', '', '', '', 0),
(49, 'guest225', '123456', '', '', '', 'ádasds', 0),
(50, 'guest765', '123456', '', '', '', 'ádasdasd', 0),
(51, 'guest816', '123456', '', '', '', 'ads', 0),
(52, 'guest984', '123456', '', '', '', 'ÂSADSAD', 0),
(53, 'guest420', '123456', '', '', '', '', 0),
(54, 'guest577', '123456', '', '', '', 'ADSFD', 0),
(55, 'guest999', '123456', '', '', '', '', 0),
(56, 'guest3', '123456', '', '', '', '', 0),
(57, 'guest410', '123456', '', '', '', '', 0),
(58, 'guest349', '123456', '', '', '', '', 0),
(59, 'guest129', '123456', '', '', '', '', 0),
(60, 'guest767', '123456', '', '', '', '', 0),
(61, 'guest543', '123456', '', '', '', '', 0),
(62, 'guest366', '123456', '', '', '', '', 0),
(63, 'guest95', '123456', '', '', '', '00', 0),
(64, 'guest478', '123456', '', '', '', '', 0),
(65, 'guest42', '123456', '', '', '', '', 0),
(66, 'guest164', '123456', '', '', '', '', 0),
(67, 'guest253', '123456', '', '', '', 'SÁ', 0),
(68, 'guest792', '123456', '', 'sai gon', 'nghia@gmail.com', '0916255152', 0),
(69, 'guest537', '123456', '', '', '', 'ádas', 0),
(70, 'guest217', '123456', '', '', '', 'ádas', 0),
(71, 'guest726', '123456', '', '', '', '', 0),
(72, 'guest538', '123456', '', '', '', '', 0),
(73, 'guest861', '123456', '', '', '', '', 0),
(74, 'guest306', '123456', '', 'sai gon', 'nghia@gmail.com', '0916255152', 0);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `bill`
--
ALTER TABLE `bill`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_bill_user` (`iduser`);

--
-- Indexes for table `binhluan`
--
ALTER TABLE `binhluan`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_binhluan_product` (`idpro`);

--
-- Indexes for table `cart`
--
ALTER TABLE `cart`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_cart_bill` (`idbill`),
  ADD KEY `fk_cart_product` (`idpro`);

--
-- Indexes for table `danhmuc`
--
ALTER TABLE `danhmuc`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `product`
--
ALTER TABLE `product`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_product_catalog` (`idcatalog`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `bill`
--
ALTER TABLE `bill`
  MODIFY `id` int(9) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=64;

--
-- AUTO_INCREMENT for table `binhluan`
--
ALTER TABLE `binhluan`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `cart`
--
ALTER TABLE `cart`
  MODIFY `id` int(6) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `danhmuc`
--
ALTER TABLE `danhmuc`
  MODIFY `id` int(3) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `product`
--
ALTER TABLE `product`
  MODIFY `id` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `id` int(6) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=75;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `bill`
--
ALTER TABLE `bill`
  ADD CONSTRAINT `fk_bill_user` FOREIGN KEY (`iduser`) REFERENCES `user` (`id`);

--
-- Constraints for table `binhluan`
--
ALTER TABLE `binhluan`
  ADD CONSTRAINT `fk_binhluan_product` FOREIGN KEY (`idpro`) REFERENCES `product` (`id`);

--
-- Constraints for table `cart`
--
ALTER TABLE `cart`
  ADD CONSTRAINT `fk_cart_bill` FOREIGN KEY (`idbill`) REFERENCES `bill` (`id`),
  ADD CONSTRAINT `fk_cart_product` FOREIGN KEY (`idpro`) REFERENCES `product` (`id`);

--
-- Constraints for table `product`
--
ALTER TABLE `product`
  ADD CONSTRAINT `fk_product_catalog` FOREIGN KEY (`idcatalog`) REFERENCES `danhmuc` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
