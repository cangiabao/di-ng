<?php
function danhmuc_all(){
    $sql = "SELECT * FROM danhmuc ORDER BY id DESC";
    return pdo_query($sql);
}
function showdm($dsdm){
    $html_dm='';
    foreach ($dsdm as $dm) {
        extract($dm);
        $likk='index.php?page=shop&iddm='.$id;
        $html_dm.='<li><a href="'.$likk.'"><i class="fa fa-angle-right"></i>'.$name.'<span class="count"></span></a></li>';
    }
    return $html_dm;
}
?>