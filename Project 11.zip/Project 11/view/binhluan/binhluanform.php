<?php
    session_start();
    ob_start();
    include "../../controller/connect.php";
    include "../../modal/binhluan.php";

    $idpro=$_REQUEST['idpro'];
    $dsbl=loadall_binhluan($idpro);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="view/layout/assets/css/bootstrap.min.css">
    <link rel="stylesheet" href="view/layout/assets/css/iconfont.min.css">
    <link rel="stylesheet" href="view/layout/assets/css/plugins.css">
    <link rel="stylesheet" href="view/layout/assets/css/helper.css">
    <link rel="stylesheet" href="view/layout/assets/css/style.css">
    <style>
        .binhluan table{
            width: 90%;
            margin-left: 5%;
        }
        .binhluan table td:nth-child(1) {
            width: 50%;
        }
        .binhluan table td:nth-child(2) {
            width: 20%;
        }
        .binhluan table td:nth-child(3) {
            width: 30%;
        }
        .input-element .review-comment-form-author input{
            background-color: #8dd2ee;
        }
        .input-element .comment-form-comment input{
            width: 40%;
            border: 2px solid #8dd2ee;
        }
    </style>
</head>
<body>
    

<div class="review-page-comment">
    <div class="review-form">
        <span class="comment-reply-title">Bình luận </span>
        <div class="description binhluan">
        <table>
            <?php
                foreach ($dsbl as $bl) {
                    extract($bl);
                    $lnkdm="index.php?act=";
                    echo '<tr><td>'.$noidung.'</td>';
                    echo '<td>'.$iduser.'</td>';
                    echo '<td>'.$ngaybinhluan.'</td></tr>';
                }

            ?>
        </table>
        </div>
        <form action="<?=$_SERVER['PHP_SELF'];?>" method="post">
            <input type="hidden" name="idpro" value="<?=$idpro?>">
            <div class="input-element">
                <div class="comment-form-comment">
                    <input type="text" name="noidung">
                </div>
                <div class="review-comment-form-author">
                    <input  type="submit" name="guibinhluan" value="Gửi bình luận">
                </div>
            </div>
        </form>
    </div>
    <?php
    if(isset($_POST['guibinhluan'])&&($_POST['guibinhluan'])){
        $noidung=$_POST['noidung'];
        $idpro=$_POST['idpro'];
        $iduser=$_SESSION['khachhang']['id'];
        $ngaybinhluan=date('h:i:sa d/m/Y');
        insert_binhluan($noidung,$iduser,$idpro,$ngaybinhluan);
        header("location: ".$_SERVER['HTTP_REFERER']);
    }
    ?>
</div>
 
</body>
</html>