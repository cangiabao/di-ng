<?php
    include_once 'model_DAO/product.php';
    include_once 'model_DAO/category.php';

    extract($_REQUEST);
    if(isset($act)){
        switch($act){
            case 'list':
                if(!isset($page)) $page=1;
                $product_page=product_page($page);
                // $product_page=product_all();

                include_once 'admin/view/header.php';
                include_once 'admin/view/page_product_list.php';
                include_once 'admin/view/footer.php';
                break;
            case 'add':
                $dsdm=category_list();
                if(isset($addProduct_submit)){
                    product_add($name,$_FILES['image']['name'],$price,$sale,$category,$quantity,$description,$hot,$status);
                    move_uploaded_file($_FILES['image']['tmp_name'],'../layout/assets/images/products/'.$_FILES['image']['name']);
                    header('location: ?page=product&act=list');
                }
                include_once 'admin/view/header.php';
                include_once 'admin/view/page_product_add.php';
                include_once 'admin/view/footer.php';
                break;
            case 'delete':
                product_delete($_GET['id']);
                header('location: ?page=product&act=list');
                break;

            case 'edit':
                $sp=product_one($id);
                $dsdm=category_list();
                if(isset($editProduct_submit)){
                    if(null != isset($_FILES['image']['name'] )){
                    product_edit($id,$name,$_FILES['image']['name'],$price,$sale,$category,$quantity,$description,$hot,$status);
                    move_uploaded_file($_FILES['image']['tmp_name'],'../layout/assets/images/products/'.$_FILES['image']['name']);
                    header('location: ?page=product&act=list');
                }else {
                    product_edit($id,$name,$sp['img'],$price,$sale,$category,$quantity,$description,$hot,$status);
                   header('location: ?page=product&act=list');
                }
                }
                include_once 'admin/view/header.php';
                include_once 'admin/view/page_product_edit.php';
                include_once 'admin/view/footer.php';
        }
    }
?>