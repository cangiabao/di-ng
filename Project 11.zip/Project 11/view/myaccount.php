<?php
    if(isset($_SESSION['s_user'])&&(count($_SESSION['s_user'])>0)){
        extract($_SESSION['s_user']);
    }
    
?>
<div class="login-register-section section pt-30 pt-lg-80 pt-md-70 pt-sm-60 pt-xs-50  pb-70 pb-lg-50 pb-md-40 pb-sm-30 pb-xs-20">
            <div class="container">
                <div class="row">
                    <div class="col-md-6 col-sm-6">
                        <div class="customer-login-register register-pt-0">
                            <div class="form-register-title">
                                <h2>Cập nhật thông tin</h2>
                            </div>
                            <div class="register-form">
                                <form action="index.php?page=updateuser" method="post">
                                    <div class="form-fild">
                                        <p><label>Số điện thoại<span class="required">*</span></label></p>
                                        <input name="username" value="<?=$username?>" type="text">
                                    </div>
                                    <div class="form-fild">
                                        <p><label>Mật khẩu<span class="required">*</span></label></p>
                                        <input name="password" value="<?=$password?>" type="password">
                                    </div>
                                    <div class="form-fild">
                                        <p><label>Địa chỉ<span class="required">*</span></label></p>
                                        <input name="diachi" value="<?=$diachi?>" type="text">
                                    </div>
                                    <div class="form-fild">
                                        <p><label>Tên<span class="required">*</span></label></p>
                                        <input name="ten" value="<?=$ten?>" type="text">
                                    </div>
                                    <div class="register-submit">
                                        <input type="hidden" name="id" value="<?=$id?>">
                                        <input type="submit" name="capnhat" class="btn" value="Cập nhật">
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>