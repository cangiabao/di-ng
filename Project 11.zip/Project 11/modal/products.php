<?php 
    function get_dssp_hot(){
        $sql="SELECT * FROM sanpham ORDER BY id DESC";
        return pdo_query($sql);
    }
    function get_dssp_new(){
        $sql="SELECT * FROM sanpham WHERE new=1 ORDER BY id DESC";
        return pdo_query($sql);
    }
    function get_dssp_best(){
        $sql="SELECT * FROM sanpham WHERE hot=1 ORDER BY hot DESC";
        return pdo_query($sql);
    }
    function get_detail_product($id){
        $sql="SELECT * FROM sanpham WHERE id = ?";
        return pdo_query_one($sql, $id);
    }
    function get_relate_products($iddm,$id){
        $sql=" SELECT * FROM sanpham WHERE iddm=? AND id<>? ORDER BY id DESC";
        return pdo_query($sql, $iddm, $id);
    }
    function get_relate_sale($iddm,$id){
        $sql=" SELECT * FROM sanpham WHERE iddm=? AND id<>? AND discount > 0 ORDER BY id DESC";
        return pdo_query($sql, $iddm, $id);
    }
    function get_dssp($kyw,$iddm){
        $sql="SELECT * FROM sanpham WHERE 1";
        if($iddm>0){
            $sql.=" AND iddm=".$iddm;
        }
        if($kyw!=''){
            $sql.=" AND name like '%".$kyw."%'";
        }
        $sql.=" ORDER BY id DESC";
        return pdo_query($sql);
    }
    function get_sp_by_id($id){
        $sql = "SELECT * FROM sanpham WHERE id=?";
        return pdo_query_one($sql, $id);
    }
    function showsp($dssp){
        $html_dssp = '';
            foreach ($dssp as $item) {
                # code...
                extract($item);
                $format_price = number_format($price, 0, ',', '.');
                $format_saleprice = number_format($saleprice, 0, ',', '.');
                if($saleprice > 0){
                    $oldprice = ' <h4 class="price"><span class="old" style="text-decoration: line-through">'. $format_price.' VND</span>
                    <br>
                    <span class="new">'.$format_saleprice.' VND</span></h4>';
                }else{
                    $oldprice= '<h4 class="price"><span class="new">'.$format_price.' VND</span></h4>';
                }
                if($discount > 0 ){
                    $percent = '<span class="descount-sticker">-'.$discount.'%</span>';
                }else{
                    $percent = '';
                }
                if($new == 1 ){
                    $new_label = '<span class="sticker">New</span>';
                }else{
                    $new_label = '';
                }
                $linkdetail = 'index.php?page=detail&idproduct='.$id;
                $html_dssp.= '
                <div class="col-12">
                <div class="single-product mb-30">
                <div class="product-img">
                    <a href="'.$linkdetail.'">
                        <img src="./layout/assets/images/products/'.$img.'" alt="">
                    </a>
                    '.$percent.'
                    '.$new_label.'
                    <div class="product-action d-flex justify-content-between">
                    <form action="index.php?page=addtocart" method="post">
                    <input type="hidden" name="id" value="'.$id.'">
                    <input type="hidden" name="name" value="'.$name.'">
                    <input type="hidden" name="img" value="'.$img.'">
                    <input type="hidden" name="price" value="'.$price.'">
                        <div class="product-quantity">
                            <input type="hidden" name="qty" value="1" type="number">
                        </div>
                        <input class="product-btn" type= "submit" name="addtocart" value= "Add to Cart">
                    </form>
                        <ul class="d-flex">
                            <li><a href="#quick-view-modal-container" data-toggle="modal"
                                    title="Quick View"><i class="fa fa-eye"></i></a></li>
                            <li><a href="#"><i class="fa fa-heart-o"></i></a></li>
                            <li><a href="#"><i class="fa fa-exchange"></i></a></li>
                        </ul>
                    </div>
                </div>
                <div class="product-content">
                    <h3><a href="'.$linkdetail.'">'.$name.'</a></h3>
                    <div class="ratting">
                        <i class="fa fa-star"></i>
                        <i class="fa fa-star"></i>
                        <i class="fa fa-star"></i>
                        <i class="fa fa-star"></i>
                        <i class="fa fa-star"></i>
                    </div>
                    '.$oldprice.'
                </div>
            </div>
            </div>
                
                ';
            }
            return $html_dssp;
       }
?>