<?php
      include_once 'modal/connect.php';

    function product_hot(){
        $sql="SELECT * FROM sanpham WHERE Hot=1 LIMIT 6";
        return pdo_query($sql);
    }
    function count_product(){
        $sql= "SELECT COUNT(*) FROM sanpham";
        return pdo_query_value($sql);
    }
    function product_page($page){
        $start=($page-1)*5;
        $sql="SELECT sp.*, dm.name as ten_dm 
        FROM sanpham sp INNER JOIN danhmuc dm ON sp.iddm = dm.id LIMIT $start,5";
        return pdo_query($sql);
    }
    // function product_all(){
        
    //     $sql="SELECT  sp.*, dm.name as ten_dm
    //     FROM sanpham as sp INNER JOIN danhmuc as dm ON sp.iddm = dm.id LIMIT 5";
    //     return pdo_query($sql);
    // }
    function product_add($name,$img,$price,$sale,$category,$quantity,$description,$hot,$status){
        $sql="INSERT INTO sanpham(name,img,price,saleprice,iddm,soluong,mota,hot,trangthai) 
        VALUE(?,?,?,?,?,?,?,?,?)";
        return pdo_query($sql,$name,$img,$price,$sale,$category,$quantity,$description,$hot,$status);
    }
    function product_delete($id){
        $sql=" DELETE FROM sanpham WHERE id=?";
        return pdo_execute($sql,$id);
    }
    function product_one($id){
        $sql="SELECT * FROM sanpham WHERE id=?";
        return pdo_query_one($sql,$id);
    }
    function product_edit($id,$name,$img,$price,$sale,$category,$quantity,$description,$hot,$status){
        $sql="UPDATE sanpham SET name=?,img=?,price=?,saleprice=?,iddm=?,soluong=?,mota=?,hot=?,trangthai=? WHERE id=?";
        return pdo_execute($sql,$name,$img,$price,$sale,$category,$quantity,$description,$hot,$status,$id);
    }
    
?>